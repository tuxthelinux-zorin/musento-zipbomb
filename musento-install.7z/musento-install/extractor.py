#!/usr/bin/env python3
import zipfile
import shutil
from pathlib import Path

def extract_zip(path: Path):
    target = path.parent / path.stem
    if target.exists():
        shutil.rmtree(target)
    target.mkdir()
    with zipfile.ZipFile(path, "r") as z:
        z.extractall(target)
    return target

def main():
    home = Path.home()
    root = home / "zip"
    root.mkdir(exist_ok=True)

    main_zip = Path("musento.zip")
    main_dir = extract_zip(main_zip)

    # extract nested zips
    for z in main_dir.rglob("*.zip"):
        extract_zip(z)

    print(f"All extraction completed inside: {root}")

if __name__ == "__main__":
    main()
